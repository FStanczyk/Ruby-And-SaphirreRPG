#include "Bag.h"

void Bag::checkBag(Player* p) {
	cout << BAG->idList[eq[0]] << endl;
}

Bag* BAG = new Bag;